const fs = require('fs');
const content = fs.readFileSync('src/components/SettingsScreen.tsx', 'utf8');

const target = `                {contract.periodBlocks.map((block) => (
                  <div key={block.id} className="flex flex-col gap-1">
                    <label className="font-mono text-[10px] font-bold text-on-surface-variant uppercase">{block.label}</label>
                    <input className="w-full bg-[#050505] border border-[#2A2A2A] rounded p-2 text-on-background text-center font-display font-bold text-[24px] input-focus outline-none" type="text" defaultValue={block.defaultTime} />
                  </div>
                ))}`;

const replacement = `                {contract.periodBlocks.map((block) => (
                  <div key={block.id} className="flex flex-col gap-1">
                    <label className="font-mono text-[10px] font-bold text-on-surface-variant uppercase">{block.label}</label>
                    <input 
                      className="w-full bg-[#050505] border border-[#2A2A2A] rounded p-2 text-on-background text-center font-display font-bold text-[24px] input-focus outline-none" 
                      type="text" 
                      defaultValue={block.id === 'p1' && periodLength !== undefined ? \`\${periodLength.toString().padStart(2, '0')}:00\` : block.defaultTime} 
                      onChange={(e) => {
                        if (block.id === 'p1') {
                          const val = e.target.value;
                          const parts = val.split(':');
                          if (parts.length > 0) {
                            const mins = parseInt(parts[0], 10);
                            if (!isNaN(mins)) {
                              setPeriodLength(mins);
                            }
                          }
                        }
                      }}
                    />
                  </div>
                ))}`;

if (content.includes(target)) {
  fs.writeFileSync('src/components/SettingsScreen.tsx', content.replace(target, replacement));
  console.log("SUCCESS");
} else {
  console.log("NOT FOUND");
}
