const fs = require('fs');
const content = fs.readFileSync('src/components/Scorekeeper/RinkMap.tsx', 'utf8');

const interfaceTarget = `  awayFallback: string;
}

interface RinkMapProps {`;
const interfaceReplacement = `  awayFallback: string;
}

interface RinkMapProps {
  rotation: number;
  onRotate: (deg: number) => void;`;

let newContent = content.replace(interfaceTarget, interfaceReplacement);

const propsTarget = `  onSaveGame: () => void;
  onEndGame: () => void;
  homeTeam: string;
  awayTeam: string;
  labels?: RinkMapLabels;
}

export default function RinkMap({`;
const propsReplacement = `  onSaveGame: () => void;
  onEndGame: () => void;
  homeTeam: string;
  awayTeam: string;
  labels?: RinkMapLabels;
}

export default function RinkMap({
  rotation,
  onRotate,`;

newContent = newContent.replace(propsTarget, propsReplacement);

const stateTarget = `  labels
}: RinkMapProps) {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);`;
const stateReplacement = `  labels
}: RinkMapProps) {
  const [zoom, setZoom] = useState(1);`;

newContent = newContent.replace(stateTarget, stateReplacement);

const rotateAction = `onClick={() => setRotation(r => (r + 90) % 360)}`;
const rotateReplacement = `onClick={() => onRotate(90)}`;
newContent = newContent.replace(rotateAction, rotateReplacement);

if (newContent !== content) {
  fs.writeFileSync('src/components/Scorekeeper/RinkMap.tsx', newContent);
  console.log("SUCCESS");
} else {
  console.log("NO CHANGES MADE");
}
