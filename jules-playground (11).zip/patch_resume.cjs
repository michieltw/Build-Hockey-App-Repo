const fs = require('fs');
const content = fs.readFileSync('src/components/ScorekeeperScreen.tsx', 'utf8');

const target = `          onResumeGame={(switchEnds) => {
            if (switchEnds) {
               setRinkRotation(prev => (prev + 180) % 360);
            }
            // Proceed to next period
            setGameState(prev => ({
               ...prev,
               period: prev.period + 1,
               timeRemaining: config.settings?.periodLength || 20 * 60,
               stoppageTime: 0
            }));
            setShowPeriodEndModal(false);
          }}`;
const replacement = `          onResumeGame={(switchEnds) => {
            if (switchEnds) {
               setRinkRotation(prev => (prev + 180) % 360);
            }
            // Proceed to next period
            setGameState(prev => {
              const nextPeriod = prev.period + 1;
              let nextTime = config.settings?.periodLength || 20 * 60;
              if (nextPeriod === 4) nextTime = 5 * 60; // OT is usually 5 mins
              if (nextPeriod >= 5) nextTime = 0; // Shootout has no time
              return {
               ...prev,
               period: nextPeriod,
               timeRemaining: nextTime,
               stoppageTime: 0
              };
            });
            setShowPeriodEndModal(false);
          }}`;

if (content.includes(target)) {
  fs.writeFileSync('src/components/ScorekeeperScreen.tsx', content.replace(target, replacement));
  console.log("SUCCESS");
} else {
  console.log("NOT FOUND");
}
