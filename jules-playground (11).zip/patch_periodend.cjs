const fs = require('fs');
const content = fs.readFileSync('src/components/Scorekeeper/PeriodEndModal.tsx', 'utf8');

const target = `EINDE PERIODE {gameState.period}`;
const replacement = `EINDE {gameState.period === 4 ? 'OT' : gameState.period >= 5 ? 'SHOOTOUT' : \`PERIODE \${gameState.period}\`}`;

fs.writeFileSync('src/components/Scorekeeper/PeriodEndModal.tsx', content.replace(target, replacement));
console.log("SUCCESS");
