const fs = require('fs');
const content = fs.readFileSync('src/components/Scorekeeper/ScoreHeader.tsx', 'utf8');

const target = `{labels?.period || ''} {gameState.period}`;
const replacement = `{gameState.period === 4 ? 'OT' : gameState.period >= 5 ? 'SO' : \`\${labels?.period || ''} \${gameState.period}\`}`;

fs.writeFileSync('src/components/Scorekeeper/ScoreHeader.tsx', content.replace(target, replacement));
console.log("SUCCESS");
