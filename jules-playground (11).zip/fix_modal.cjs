const fs = require('fs');
const content = fs.readFileSync('src/components/Scorekeeper/PeriodEndModal.tsx', 'utf8');

const newContent = content.replace(/\\\`\\\$\{leftPct\}%\\\`/g, '`${leftPct}%`').replace(/\\\`\\\$\{rightPct\}%\\\`/g, '`${rightPct}%`');

fs.writeFileSync('src/components/Scorekeeper/PeriodEndModal.tsx', newContent);
console.log("SUCCESS");
