import React, { useState, useEffect } from 'react';
import { getDatabase, saveDatabase, switchUserRole, resetDatabase, createPerson, updateTheme, updateCurrentUser } from './services';
import { AppDatabase, UserRole, Person } from './types';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { ProfileSection } from './components/ProfileSection';
import { StandardUserDashboard } from './components/StandardUserDashboard';
import { CompetitieDashboard } from './components/CompetitieDashboard';
import { LeagueOverview } from './components/LeagueOverview';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [db, setDb] = useState<AppDatabase>(() => getDatabase());
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const currentDb = getDatabase();
    return currentDb.settings?.generalSettings?.theme === 'dark';
  });
  const [isFading, setIsFading] = useState<boolean>(false);
  const [fadePhase, setFadePhase] = useState<'idle' | 'in' | 'out'>('idle');

  // Synchronize system themes from DB updates if any
  useEffect(() => {
    setIsDarkMode(db.settings?.generalSettings?.theme === 'dark');
  }, [db.settings?.generalSettings?.theme]);

  // Apply dark mode class to html element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleBlackoutClick = () => {
    if (isFading) return;
    setIsFading(true);
    setFadePhase('in');
  };

  const handleFadeComplete = () => {
    if (fadePhase === 'in') {
      const nextDark = !isDarkMode;
      setIsDarkMode(nextDark);
      
      const updatedDb = { ...db };
      if (!updatedDb.settings) {
        updatedDb.settings = {} as any;
      }
      if (!updatedDb.settings.generalSettings) {
        updatedDb.settings.generalSettings = {} as any;
      }
      const nextTheme = nextDark ? 'dark' : 'light';
      const newDb = updateTheme(nextTheme);
      setDb(newDb);
      
      setFadePhase('out');
    } else if (fadePhase === 'out') {
      setFadePhase('idle');
      setIsFading(false);
    }
  };

  // Listen to cross-component database updates (useful for real-time state sync)
  useEffect(() => {
    const handleDbUpdate = () => {
      setDb(getDatabase());
    };
    window.addEventListener('app_db_update', handleDbUpdate);
    return () => {
      window.removeEventListener('app_db_update', handleDbUpdate);
    };
  }, []);

  const handleUpdateDb = (updatedDb: AppDatabase) => {
    setDb({ ...updatedDb });
  };

  const handleSwitchRole = (role: UserRole, personId: string | null) => {
    const updated = switchUserRole(role, personId);
    setDb(updated);
    if (role === 'StandardUser') {
      setActiveTab('player-dashboard');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleResetDb = () => {
    const isConfirmed = window.confirm(
      'Weet je zeker dat je de gehele database wilt resetten naar de beginstand? Alle opgeslagen wijzigingen, teams, wedstrijden en statistieken worden hersteld.'
    );
    if (isConfirmed) {
      const reset = resetDatabase();
      setDb(reset);
      setActiveTab('dashboard');
    }
  };

  const [showSplash, setShowSplash] = useState<boolean>(() => {
    return sessionStorage.getItem('hasCompletedSplash') !== 'true';
  });

  const handleLogin = (role: UserRole, personId: string | null, username: string, email: string) => {
    const updated = { ...db };
    const newUser = {
      id: personId ? `user-${personId}` : `user-${Date.now()}`,
      username,
      email,
      systemRole: role,
      personId
    };
    const newDb = updateCurrentUser(newUser);
    setDb(newDb);
    
    if (role === 'StandardUser') {
      setActiveTab('player-dashboard');
    } else {
      setActiveTab('dashboard');
    }
    sessionStorage.setItem('hasCompletedSplash', 'true');
    setShowSplash(false);
  };

  const handleRegister = (newPersonData: Omit<Person, 'id'>, systemRole: UserRole, email: string) => {
    const updatedDb = createPerson(newPersonData);
    setDb(updatedDb);
    
    // Find the newly created person (last item in list)
    const newPerson = updatedDb.persons[updatedDb.persons.length - 1];
    const newPersonId = newPerson ? newPerson.id : null;
    
    handleLogin(systemRole, newPersonId, newPersonData.name, email);
  };

  const handleContinueAsGuest = () => {
    handleLogin('Guest', null, 'Gastlezer', 'gast@test.nl');
  };

  const handleLogout = () => {
    sessionStorage.setItem('hasCompletedSplash', 'false');
    setShowSplash(true);
  };

  if (showSplash) {
    return (
      <SplashScreen
        db={db}
        onLogin={handleLogin}
        onRegister={handleRegister}
        onContinueAsGuest={handleContinueAsGuest}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F7FA] text-slate-900 flex flex-col font-sans selection:bg-slate-900 selection:text-white" id="app-root">
      {/* Top Header & Simulation Controller */}
      <Header
        db={db}
        onSwitchRole={handleSwitchRole}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onResetDb={handleResetDb}
        isDarkMode={isDarkMode}
        onLogoClick={handleBlackoutClick}
        onLogout={handleLogout}
      />

      {/* Main Container */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20" id="app-main">
        {/* Active Tab View rendering */}
        {activeTab === 'dashboard' && <Dashboard db={db} onUpdateDb={handleUpdateDb} />}

        {activeTab === 'league-overview' && (
          <LeagueOverview db={db} setActiveTab={setActiveTab} />
        )}
        
        {activeTab === 'player-dashboard' && (
          <StandardUserDashboard db={db} onUpdateDb={handleUpdateDb} />
        )}
        
        {activeTab === 'profile' && (
          <ProfileSection db={db} onUpdateDb={handleUpdateDb} />
        )}

        {activeTab.startsWith('comp-') && (
          <CompetitieDashboard 
            db={db} 
            onUpdateDb={handleUpdateDb} 
            activeSubTab={activeTab.substring(5)} 
            setActiveTab={setActiveTab}
          />
        )}
      </main>

      {/* Footer info and role status indicator */}
      <footer className="bg-white/80 border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-500 " id="app-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="font-sans text-slate-500">
            &copy; 2026 App MLM. Alle rechten voorbehouden.
          </p>
          <div className="flex items-center space-x-2 font-mono text-[10px] text-slate-500">
            <span className="w-2 h-2 rounded-full bg-slate-100 animate-pulse"></span>
            <span>Huidige actieve sessie: <strong className="text-slate-700">{db.currentUser?.username}</strong> ({db.currentUser?.systemRole})</span>
          </div>
        </div>
      </footer>

      {/* Cinematic Overlay */}
      <AnimatePresence>
        {isFading && (
          <motion.div
            key={fadePhase}
            initial={{ opacity: fadePhase === 'in' ? 0 : 1 }}
            animate={{ opacity: fadePhase === 'in' ? 1 : 0 }}
            exit={{ opacity: fadePhase === 'in' ? 1 : 0 }}
            transition={{
              duration: fadePhase === 'in' ? 2.5 : 0.8, // Heel langzaam in (2.5s), sneller uit (0.8s)
              ease: "easeInOut"
            }}
            onAnimationComplete={handleFadeComplete}
            className="fixed inset-0 bg-black z-[9999] pointer-events-none"
          />
        )}
      </AnimatePresence>
    </div>
  );
}
