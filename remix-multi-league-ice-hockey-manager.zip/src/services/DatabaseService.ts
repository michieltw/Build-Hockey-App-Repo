import { AppDatabase, UserRole } from '../types';
import { initialDatabase } from '../db/initialData';

const LOCAL_STORAGE_KEY = 'sports_manager_db';

export function getDatabase(): AppDatabase {
  if (typeof window === 'undefined') return initialDatabase;
  const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(initialDatabase));
    return initialDatabase;
  }
  try {
    const db = JSON.parse(stored) as AppDatabase;
    let needsSave = false;

    // 1. Ensure all root keys from initialDatabase exist in the loaded db
    for (const key of Object.keys(initialDatabase) as Array<keyof AppDatabase>) {
      if (db[key] === undefined) {
        (db as any)[key] = initialDatabase[key];
        needsSave = true;
      }
    }

    // Ensure currentUser is always defined
    if (!db.currentUser) {
      db.currentUser = initialDatabase.currentUser;
      needsSave = true;
    }

    // 2. Sync avatars of seed persons if they have the old Unsplash avatars or if the seed person is updated in initialDatabase
    if (db.persons) {
      db.persons = db.persons.map(p => {
        const initialPerson = initialDatabase.persons.find(ip => ip.id === p.id);
        if (initialPerson) {
          if (p.avatar !== initialPerson.avatar && (p.avatar.includes('unsplash') || initialPerson.avatar.includes('shopify'))) {
            needsSave = true;
            return { ...p, avatar: initialPerson.avatar };
          }
        }
        return p;
      });
    }

    if (db.association?.locations?.[0]) {
      if (db.association.locations[0].name !== 'Standaard Locatie') {
        db.association.locations[0].name = 'Standaard Locatie';
        needsSave = true;
      }
    }

    const primaryLoc = db.association?.locations?.[0]?.name || 'Standaard Locatie';

    if (db.teams) {
      db.teams.forEach(t => {
        if (!t.stadium || t.stadium.includes('Standaard Locatie') || t.stadium.includes('Sportcentrum') || t.stadium.includes('Arena')) {
          if (t.stadium !== primaryLoc) {
            t.stadium = primaryLoc;
            needsSave = true;
          }
        }
      });
    }

    if (db.calendarEvents) {
      db.calendarEvents.forEach(e => {
        if (!e.location || e.location.includes('Standaard Locatie') || e.location.includes('Sportcentrum') || e.location.includes('Arena') || e.location.includes('Ijsbaan') || e.location.includes('Rink')) {
          if (e.location !== primaryLoc) {
            e.location = primaryLoc;
            needsSave = true;
          }
        }
      });
    }

    if (needsSave) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(db));
    }

    return db;
  } catch (e) {
    console.error('Error parsing stored database, resetting to initial', e);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(initialDatabase));
    return initialDatabase;
  }
}

export function saveDatabase(db: AppDatabase): AppDatabase {
  if (typeof window !== 'undefined') {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(db));
    // Trigger window event for potential real-time sync across components/tabs
    window.dispatchEvent(new Event('app_db_update'));
  }
  return db;
}

export function resetDatabase(): AppDatabase {
  saveDatabase(initialDatabase);
  return initialDatabase;
}

// Authorization check helper
export function checkPermission(role: UserRole, action: 'manage_team' | 'manage_league' | 'manage_all_leagues', contextId?: string): boolean {
  if (role === 'MultiLeagueOfficer') return true;
  
  if (role === 'LeagueOfficer') {
    if (action === 'manage_all_leagues') return false;
    if (action === 'manage_league') return true; // Can manage assigned league
    if (action === 'manage_team') {
      // League officers can also manage teams within their league
      const db = getDatabase();
      if (!contextId) return true;
      const team = db.teams.find(t => t.id === contextId);
      const assignedLeagues = db.leagues.filter(l => l.officerId === db.currentUser.personId).map(l => l.id);
      return team ? team.leagueIds.some(lid => assignedLeagues.includes(lid)) : false;
    }
  }

  if (role === 'Manager') {
    if (action === 'manage_all_leagues' || action === 'manage_league') return false;
    if (action === 'manage_team') {
      const db = getDatabase();
      const person = db.persons.find(p => p.id === db.currentUser.personId);
      if (!person) return false;
      return person.managedTeamId === contextId || teamHasManager(contextId || '', person.id);
    }
  }

  return false; // Guest has no edit permissions
}

function teamHasManager(teamId: string, managerId: string): boolean {
  const db = getDatabase();
  const team = db.teams.find(t => t.id === teamId);
  return team ? team.managerId === managerId : false;
}

export function updateTheme(theme: 'light' | 'dark'): AppDatabase {
  const db = getDatabase();
  if (!db.settings) {
    db.settings = {} as any;
  }
  if (!db.settings.generalSettings) {
    db.settings.generalSettings = {} as any;
  }
  db.settings.generalSettings.theme = theme;
  saveDatabase(db);
  return db;
}

export function updateCurrentUser(user: { id: string, username: string, email: string, systemRole: UserRole, personId: string | null }): AppDatabase {
  const db = getDatabase();
  db.currentUser = user;
  saveDatabase(db);
  return db;
}
