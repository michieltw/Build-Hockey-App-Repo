import { Match, MatchEvent, AppDatabase } from '../types';
import { getDatabase, saveDatabase } from './DatabaseService';

export function scheduleMatch(match: Omit<Match, 'id' | 'status'>): AppDatabase {
  const db = getDatabase();
  const id = `match-${Date.now()}`;
  db.matches.push({
    ...match,
    id,
    status: 'Gepland'
  });
  saveDatabase(db); return db;
}

export function updateMatchScore(matchId: string, status: Match['status'], events: MatchEvent[], homeScore: number, awayScore: number): AppDatabase {
  const db = getDatabase();
  const matchIndex = db.matches.findIndex(m => m.id === matchId);
  if (matchIndex === -1) return;
  
  const currentMatch = db.matches[matchIndex];
  db.matches[matchIndex] = {
    ...currentMatch,
    status,
    events,
    homeScore,
    awayScore
  };
  saveDatabase(db); return db;
}

export function assignRefereesToMatch(matchId: string, referees: string[]): AppDatabase {
  const db = getDatabase();
  const matchIndex = db.matches.findIndex(m => m.id === matchId);
  if (matchIndex === -1) return;

  db.matches[matchIndex].referees = referees;
  saveDatabase(db); return db;
}

export function addMatch(match: Match): AppDatabase {
  const db = getDatabase();
  db.matches.push(match);
  saveDatabase(db);
  return db;
}

export function resetMatch(matchId: string): AppDatabase {
  const db = getDatabase();
  db.matches = db.matches.map(m => {
    if (m.id === matchId) {
      return {
        ...m,
        status: 'Gepland',
        homeScore: 0,
        awayScore: 0,
        events: []
      };
    }
    return m;
  });
  saveDatabase(db);
  return db;
}
